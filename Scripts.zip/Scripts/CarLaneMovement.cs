using UnityEngine;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Controls car lane movement using Left and Right arrow keys with discrete position snapping
/// and smooth interpolation transitions.
/// Works seamlessly with both Unity's New Input System and Legacy Input Manager.
/// </summary>
[AddComponentMenu("Vehicles/Car Lane Movement")]
public class CarLaneMovement : MonoBehaviour
{
    [Header("--- Lane Configuration ---")]
    [Tooltip("Distance between each lane along the horizontal (X) axis.")]
    [SerializeField] private float laneDistance = 2.5f;

    [Tooltip("Leftmost lane index (e.g. -1 for 3-lane setup: -1 Left, 0 Center, 1 Right).")]
    [SerializeField] private int minLaneIndex = -1;

    [Tooltip("Rightmost lane index (e.g. 1 for 3-lane setup: -1 Left, 0 Center, 1 Right).")]
    [SerializeField] private int maxLaneIndex = 1;

    [Tooltip("Starting lane index on Awake/Start.")]
    [SerializeField] private int startingLaneIndex = 0;

    public enum TransitionMode
    {
        SmoothDamp, // Natural spring-like acceleration and deceleration without overshoot
        Lerp        // Linear exponential smoothing
    }

    [Header("--- Smooth Transition ---")]
    [Tooltip("Smoothing technique for transitioning between lanes.")]
    [SerializeField] private TransitionMode transitionMode = TransitionMode.SmoothDamp;

    [Tooltip("Approximate time (in seconds) to reach target lane when using SmoothDamp (lower is faster/snappier).")]
    [Range(0.02f, 0.5f)]
    [SerializeField] private float smoothDampTime = 0.12f;

    [Tooltip("Interpolation speed when using Lerp mode.")]
    [SerializeField] private float lerpSpeed = 15f;

    [Header("--- Forward Movement (Optional) ---")]
    [Tooltip("Constant forward speed along the Z axis (set to 0 for stationary sideways movement).")]
    [SerializeField] private float forwardSpeed = 0f;

    [Header("--- Banking / Roll Effect (Juice) ---")]
    [Tooltip("Enable subtle car body tilt/lean when switching lanes.")]
    [SerializeField] private bool enableBanking = true;

    [Tooltip("Maximum roll tilt angle (in degrees) during lane change.")]
    [Range(0f, 25f)]
    [SerializeField] private float maxBankAngle = 8f;

    [Tooltip("How quickly the body rolls into and out of the turn.")]
    [SerializeField] private float bankSpeed = 10f;

    [Header("--- Custom Explicit Lanes (Optional) ---")]
    [Tooltip("Enable if you prefer explicit X coordinates instead of equidistant lane steps.")]
    [SerializeField] private bool useCustomLanePositions = false;

    [Tooltip("Array of fixed X coordinates from left to right (e.g. -2.5, 0, 2.5).")]
    [SerializeField] private float[] customLaneXPositions = new float[] { -2.5f, 0f, 2.5f };

    public enum ResetMode
    {
        RestartScene,   // Reloads the active scene (standard arcade restart)
        ResetPosition   // Snaps car back to start lane & position, destroys active obstacles
    }

    [Header("--- Collision & Reset ---")]
    [Tooltip("How the car resets when colliding with an obstacle.")]
    [SerializeField] private ResetMode resetMode = ResetMode.RestartScene;

    [Tooltip("Delay (in seconds) before resetting to give visual feedback on crash.")]
    [Range(0f, 3f)]
    [SerializeField] private float resetDelay = 0.5f;

    [Tooltip("Tags that trigger a crash on contact.")]
    [SerializeField] private string[] obstacleTags = new string[] { "Obstacle" };

    [Tooltip("Automatically setup Rigidbody and BoxCollider if missing at runtime.")]
    [SerializeField] private bool autoSetupPhysics = true;

    [Header("--- Collider Calibration ---")]
    [Tooltip("Precise collider dimensions matching a single lane.")]
    [SerializeField] private Vector3 colliderSize = new Vector3(1.8f, 1.2f, 4.0f);

    [Tooltip("Offset of the collider relative to the car root.")]
    [SerializeField] private Vector3 colliderCenter = new Vector3(0f, 0.6f, 0f);

    [Tooltip("Particle effect or prefab to instantiate on crash (optional).")]
    [SerializeField] private GameObject crashVfxPrefab;

    [Tooltip("Audio clip to play on crash (optional).")]
    [SerializeField] private AudioClip crashSound;

    [Header("--- Debug ---")]
    [Tooltip("Print key press detection and lane transitions to the Unity Console.")]
    [SerializeField] private bool showDebugLogs = true;

    [Header("--- References ---")]
    [Tooltip("Drag the GameManager object here (optional).")]
    [SerializeField] private GameManager gameManager;

    // Internal State
    private int currentLaneIndex;
    private float targetX;
    private float initialX;
    private Vector3 initialPosition;
    private Quaternion initialRotation;
    private float xVelocity; // Used by Mathf.SmoothDamp
    private float currentBankAngle;
    private bool isAlive = true;
    private bool isResetting = false;

    /// <summary>
    /// Read-only property to check current lane index.
    /// </summary>
    public int CurrentLaneIndex => currentLaneIndex;

    /// <summary>
    /// Read-only property to check whether the car is currently mid-transition.
    /// </summary>
    public bool IsTransitioning => Mathf.Abs(transform.position.x - targetX) > 0.01f;

    private void Awake()
    {
        // Remember starting reference
        initialPosition = transform.position;
        initialRotation = transform.rotation;
        initialX = transform.position.x;
        currentLaneIndex = Mathf.Clamp(startingLaneIndex, minLaneIndex, maxLaneIndex);
        targetX = CalculateLaneTargetX(currentLaneIndex);

        // Snap car immediately to starting lane position on start
        Vector3 pos = transform.position;
        pos.x = targetX;
        transform.position = pos;

        if (autoSetupPhysics)
        {
            EnsurePhysicsSetup();
        }
    }

    private void Start()
    {
        if (gameManager == null)
        {
            gameManager = Object.FindFirstObjectByType<GameManager>();
        }
    }

    /// <summary>
    /// Ensures car has a Rigidbody (Kinematic) and BoxCollider with exact calibrated dimensions.
    /// </summary>
    [ContextMenu("Setup Accurate Car Collider & Rigidbody")]
    public void EnsurePhysicsSetup()
    {
        // 1. Ensure Rigidbody exists (Kinematic so car moves via script without unintended physics forces)
        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = gameObject.AddComponent<Rigidbody>();
        }
        rb.isKinematic = true;
        rb.useGravity = false;

        // 2. Ensure BoxCollider exists with explicit, accurate dimensions
        BoxCollider box = GetComponent<BoxCollider>();
        if (box == null)
        {
            box = gameObject.AddComponent<BoxCollider>();
        }

        // Apply clean calibrated dimensions (fits a single 2.5m lane with clearance)
        box.size = colliderSize;
        box.center = colliderCenter;
        box.isTrigger = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        HandleHit(other.gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        HandleHit(collision.gameObject);
    }

    private void HandleHit(GameObject hitObj)
    {
        if (!isAlive || isResetting || hitObj == null) return;

        if (IsObstacle(hitObj))
        {
            // Verify spatial proximity to prevent false triggers across lanes or far ahead
            if (!IsSpatialHit(hitObj.transform)) return;

            OnCrash();
        }
    }

    /// <summary>
    /// Validates the obstacle is genuinely within collision range in both X and Z.
    /// Prevents phantom triggers, out-of-lane collisions, and premature crashes.
    /// </summary>
    private bool IsSpatialHit(Transform obstacleTransform)
    {
        if (obstacleTransform == null) return false;

        // 1. Longitudinal distance: must be near the car bumper (not 50m ahead!)
        float deltaZ = obstacleTransform.position.z - transform.position.z;
        if (deltaZ > 2.5f || deltaZ < -3.5f) return false;

        // 2. Lateral distance: must be in the same lane!
        float deltaX = Mathf.Abs(obstacleTransform.position.x - transform.position.x);
        if (deltaX > 1.6f) return false;

        return true;
    }

    private bool IsObstacle(GameObject hitObj)
    {
        if (hitObj == null) return false;

        // Check for Obstacle component in parent or children
        if (hitObj.GetComponentInParent<Obstacle>() != null || hitObj.GetComponentInChildren<Obstacle>() != null)
        {
            return true;
        }

        // Check tags safely
        if (obstacleTags != null)
        {
            foreach (string tag in obstacleTags)
            {
                if (!string.IsNullOrEmpty(tag))
                {
                    try
                    {
                        if (hitObj.CompareTag(tag)) return true;
                    }
                    catch { }
                }
            }
        }

        // Check common naming patterns
        string lower = hitObj.name.ToLower();
        if (lower.Contains("obstacle") || lower.Contains("hazard") || lower.Contains("barrier"))
        {
            return true;
        }

        return false;
    }

    private void Update()
    {
        if (!isAlive) return;

        HandleInput();
        UpdatePosition();
        if (enableBanking)
        {
            UpdateBanking();
        }
    }

    /// <summary>
    /// Called when the car collides with an obstacle.
    /// </summary>
    public void OnCrash()
    {
        if (!isAlive || isResetting) return;
        isAlive = false;

        if (showDebugLogs) Debug.Log("<color=red><b>💥 CRASH! Car collided with an obstacle!</b></color>");

        // Audio feedback
        if (crashSound != null)
        {
            AudioSource.PlayClipAtPoint(crashSound, transform.position);
        }

        // Visual FX
        if (crashVfxPrefab != null)
        {
            Instantiate(crashVfxPrefab, transform.position, Quaternion.identity);
        }

        if (gameManager != null)
        {
            gameManager.TriggerFailure("You crashed into an obstacle!");
        }

        StartCoroutine(ResetRoutine());
    }

    private System.Collections.IEnumerator ResetRoutine()
    {
        isResetting = true;

        if (resetDelay > 0f)
        {
            yield return new WaitForSecondsRealtime(resetDelay);
        }

        if (resetMode == ResetMode.RestartScene)
        {
            Time.timeScale = 1f;
            UnityEngine.SceneManagement.SceneManager.LoadScene(
                UnityEngine.SceneManagement.SceneManager.GetActiveScene().name
            );
        }
        else
        {
            ResetCarState();
        }
    }

    /// <summary>
    /// Resets car position, lane, and eliminates active obstacles without reloading the scene.
    /// </summary>
    public void ResetCarState()
    {
        currentLaneIndex = Mathf.Clamp(startingLaneIndex, minLaneIndex, maxLaneIndex);
        targetX = CalculateLaneTargetX(currentLaneIndex);

        Vector3 pos = initialPosition;
        pos.x = targetX;
        transform.position = pos;
        transform.rotation = initialRotation;

        currentBankAngle = 0f;
        xVelocity = 0f;

        // Clear active obstacles on the road so car doesn't immediately crash again
        ObstacleSpawner spawner = Object.FindFirstObjectByType<ObstacleSpawner>();
        if (spawner != null)
        {
            spawner.ClearAllObstacles();
            spawner.ResetSpawner();
        }
        else
        {
            Obstacle[] obstacles = Object.FindObjectsByType<Obstacle>(FindObjectsSortMode.None);
            foreach (Obstacle obs in obstacles)
            {
                if (obs != null) Destroy(obs.gameObject);
            }
        }

        isAlive = true;
        isResetting = false;
        Time.timeScale = 1f;

        if (showDebugLogs) Debug.Log("<color=green><b>✔ Car reset to starting position and lane. Ready!</b></color>");
    }

    public bool IsAlive() => isAlive;

    /// <summary>
    /// Detects Left / Right arrow key presses across both New Input System and Legacy Input.
    /// </summary>
    private void HandleInput()
    {
        bool leftPressed = false;
        bool rightPressed = false;

#if ENABLE_INPUT_SYSTEM
        // Modern Unity Input System
        if (Keyboard.current != null)
        {
            leftPressed = Keyboard.current.leftArrowKey.wasPressedThisFrame || Keyboard.current.aKey.wasPressedThisFrame;
            rightPressed = Keyboard.current.rightArrowKey.wasPressedThisFrame || Keyboard.current.dKey.wasPressedThisFrame;
        }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        // Legacy Input Manager fallback
        if (!leftPressed)
        {
            leftPressed = Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A);
        }
        if (!rightPressed)
        {
            rightPressed = Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D);
        }
#endif

        // Trigger discrete lane shifts
        if (leftPressed)
        {
            if (showDebugLogs) Debug.Log($"[CarLaneMovement] <color=yellow>Left Arrow / A key detected</color>");
            MoveToLeftLane();
        }
        else if (rightPressed)
        {
            if (showDebugLogs) Debug.Log($"[CarLaneMovement] <color=yellow>Right Arrow / D key detected</color>");
            MoveToRightLane();
        }
    }

    /// <summary>
    /// Snaps target to the lane on the left.
    /// </summary>
    public void MoveToLeftLane()
    {
        int minLimit = useCustomLanePositions && customLaneXPositions != null && customLaneXPositions.Length > 0
            ? 0
            : minLaneIndex;

        if (currentLaneIndex > minLimit)
        {
            currentLaneIndex--;
            targetX = CalculateLaneTargetX(currentLaneIndex);
            if (showDebugLogs) Debug.Log($"[CarLaneMovement] <color=green>Shifted Left -> Lane: {currentLaneIndex}</color> (Target X = {targetX:F2})");
        }
        else
        {
            if (showDebugLogs) Debug.Log($"[CarLaneMovement] <color=orange>Already at leftmost lane ({currentLaneIndex})</color>");
        }
    }

    /// <summary>
    /// Snaps target to the lane on the right.
    /// </summary>
    public void MoveToRightLane()
    {
        int maxLimit = useCustomLanePositions && customLaneXPositions != null && customLaneXPositions.Length > 0
            ? customLaneXPositions.Length - 1
            : maxLaneIndex;

        if (currentLaneIndex < maxLimit)
        {
            currentLaneIndex++;
            targetX = CalculateLaneTargetX(currentLaneIndex);
            if (showDebugLogs) Debug.Log($"[CarLaneMovement] <color=green>Shifted Right -> Lane: {currentLaneIndex}</color> (Target X = {targetX:F2})");
        }
        else
        {
            if (showDebugLogs) Debug.Log($"[CarLaneMovement] <color=orange>Already at rightmost lane ({currentLaneIndex})</color>");
        }
    }

    /// <summary>
    /// Jump directly to a specific lane index (with bounds check).
    /// </summary>
    public void SetLane(int newLaneIndex)
    {
        int minLimit = useCustomLanePositions && customLaneXPositions != null && customLaneXPositions.Length > 0
            ? 0
            : minLaneIndex;
        int maxLimit = useCustomLanePositions && customLaneXPositions != null && customLaneXPositions.Length > 0
            ? customLaneXPositions.Length - 1
            : maxLaneIndex;

        currentLaneIndex = Mathf.Clamp(newLaneIndex, minLimit, maxLimit);
        targetX = CalculateLaneTargetX(currentLaneIndex);
    }

    /// <summary>
    /// Computes world X position for a given lane index.
    /// </summary>
    private float CalculateLaneTargetX(int lane)
    {
        if (useCustomLanePositions && customLaneXPositions != null && customLaneXPositions.Length > 0)
        {
            int index = Mathf.Clamp(lane, 0, customLaneXPositions.Length - 1);
            return customLaneXPositions[index];
        }

        return initialX + (lane * laneDistance);
    }

    /// <summary>
    /// Smoothly transitions current position towards target lane position.
    /// </summary>
    private void UpdatePosition()
    {
        Vector3 currentPosition = transform.position;
        float newX = currentPosition.x;

        switch (transitionMode)
        {
            case TransitionMode.SmoothDamp:
                newX = Mathf.SmoothDamp(currentPosition.x, targetX, ref xVelocity, smoothDampTime);
                break;

            case TransitionMode.Lerp:
                newX = Mathf.Lerp(currentPosition.x, targetX, Time.deltaTime * lerpSpeed);
                break;
        }

        // Apply forward movement if enabled
        float newZ = currentPosition.z + (forwardSpeed * Time.deltaTime);

        transform.position = new Vector3(newX, currentPosition.y, newZ);
    }

    /// <summary>
    /// Adds a dynamic tilt / banking effect when moving horizontally between lanes.
    /// </summary>
    private void UpdateBanking()
    {
        // Distance difference between target and current position
        float deltaX = targetX - transform.position.x;

        // Calculate target bank: rolling into the turn (negative delta -> tilt left, positive -> tilt right)
        float targetBank = Mathf.Clamp(-deltaX * (maxBankAngle / Mathf.Max(laneDistance, 0.1f)), -maxBankAngle, maxBankAngle);

        currentBankAngle = Mathf.Lerp(currentBankAngle, targetBank, Time.deltaTime * bankSpeed);

        // Apply tilt to local Z rotation
        Vector3 currentAngles = transform.localEulerAngles;
        transform.localEulerAngles = new Vector3(currentAngles.x, currentAngles.y, currentBankAngle);
    }

    /// <summary>
    /// Visualizes lane positions and center point in the Unity Editor Scene view.
    /// </summary>
    private void OnDrawGizmosSelected()
    {
        float baseX = Application.isPlaying ? initialX : transform.position.x;
        float y = transform.position.y;
        float z = transform.position.z;

        if (useCustomLanePositions && customLaneXPositions != null)
        {
            for (int i = 0; i < customLaneXPositions.Length; i++)
            {
                float lx = customLaneXPositions[i];
                Gizmos.color = (i == currentLaneIndex) ? Color.green : Color.cyan;
                Gizmos.DrawLine(new Vector3(lx, y, z - 10f), new Vector3(lx, y, z + 10f));
                Gizmos.DrawWireSphere(new Vector3(lx, y, z), 0.3f);
            }
        }
        else
        {
            for (int lane = minLaneIndex; lane <= maxLaneIndex; lane++)
            {
                float lx = baseX + (lane * laneDistance);
                Gizmos.color = (lane == currentLaneIndex) ? Color.green : Color.cyan;
                Gizmos.DrawLine(new Vector3(lx, y, z - 10f), new Vector3(lx, y, z + 10f));
                Gizmos.DrawWireSphere(new Vector3(lx, y, z), 0.3f);
            }
        }
    }
}
