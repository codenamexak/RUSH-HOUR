#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

/// <summary>
/// Editor utility to configure or create a 3-lane road plane in 1 click.
/// Available from Unity menu: Tools > Road > Setup Road On Selected Plane
/// </summary>
public static class RoadSetupWizard
{
    private const string TexturePath = "Assets/Textures/Road_3Lane.png";
    private const string MaterialPath = "Assets/Materials/RoadMaterial.mat";

    [MenuItem("Tools/Road/Setup Road On Selected Plane", false, 10)]
    public static void SetupRoadOnSelectedPlane()
    {
        GameObject selected = Selection.activeGameObject;
        if (selected == null)
        {
            EditorUtility.DisplayDialog(
                "No Object Selected",
                "Please select your 'Plane' GameObject in the Hierarchy first, then run this again.",
                "OK"
            );
            return;
        }

        ConfigureGameObjectAsRoad(selected);
    }

    [MenuItem("Tools/Road/Create New 3-Lane Road Plane", false, 11)]
    public static void CreateNewRoadPlane()
    {
        GameObject plane = GameObject.CreatePrimitive(PrimitiveType.Plane);
        plane.name = "Road_Plane";
        Undo.RegisterCreatedObjectUndo(plane, "Create Road Plane");

        ConfigureGameObjectAsRoad(plane);
        Selection.activeGameObject = plane;
    }

    [MenuItem("Tools/Road/Setup Car Collision & Rigidbody", false, 12)]
    public static void SetupCarPhysicsMenu()
    {
        SetupCarPhysics();
    }

    [MenuItem("Tools/Road/Create Obstacle Spawner", false, 20)]
    public static void CreateObstacleSpawner()
    {
        ObstacleSpawner existing = Object.FindFirstObjectByType<ObstacleSpawner>();
        if (existing != null)
        {
            Selection.activeGameObject = existing.gameObject;
            EditorGUIUtility.PingObject(existing.gameObject);
            Debug.Log("Obstacle Spawner already exists in the scene!", existing.gameObject);
            return;
        }

        GameObject spawnerGo = new GameObject("Obstacle_Spawner");
        Undo.RegisterCreatedObjectUndo(spawnerGo, "Create Obstacle Spawner");
        spawnerGo.AddComponent<ObstacleSpawner>();
        spawnerGo.transform.position = new Vector3(0f, 0f, 50f);

        // Ensure car has proper Collider and Rigidbody for collision detection
        SetupCarPhysics();

        Selection.activeGameObject = spawnerGo;
        EditorGUIUtility.PingObject(spawnerGo);
        Debug.Log("<color=green>✔ Successfully created 'Obstacle_Spawner'!</color>", spawnerGo);
    }

    private static void SetupCarPhysics()
    {
        CarLaneMovement carLane = Object.FindFirstObjectByType<CarLaneMovement>();
        CarController carCtrl = Object.FindFirstObjectByType<CarController>();
        GameObject car = carLane != null ? carLane.gameObject : (carCtrl != null ? carCtrl.gameObject : Selection.activeGameObject);

        if (car == null)
        {
            EditorUtility.DisplayDialog(
                "Car Not Found",
                "Please select your car in the Hierarchy first, or ensure a GameObject with CarLaneMovement or CarController exists in the scene.",
                "OK"
            );
            return;
        }

        // Rigidbody setup
        Rigidbody rb = car.GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = Undo.AddComponent<Rigidbody>(car);
        }
        Undo.RecordObject(rb, "Configure Rigidbody");
        rb.isKinematic = true;
        rb.useGravity = false;

        // BoxCollider setup
        BoxCollider box = car.GetComponent<BoxCollider>();
        if (box == null)
        {
            box = car.GetComponentInChildren<BoxCollider>();
        }
        if (box == null)
        {
            box = Undo.AddComponent<BoxCollider>(car);
        }

        Undo.RecordObject(box, "Configure BoxCollider");

        // Auto-fit box to renderers if available
        Renderer[] renderers = car.GetComponentsInChildren<Renderer>();
        if (renderers.Length > 0)
        {
            Bounds b = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++)
            {
                b.Encapsulate(renderers[i].bounds);
            }

            Vector3 localCenter = car.transform.InverseTransformPoint(b.center);
            Vector3 localSize = car.transform.InverseTransformVector(b.size);
            box.center = localCenter;
            box.size = new Vector3(Mathf.Abs(localSize.x), Mathf.Abs(localSize.y), Mathf.Abs(localSize.z));
        }
        else
        {
            box.size = new Vector3(1.8f, 1.2f, 4f);
            box.center = new Vector3(0f, 0.6f, 0f);
        }

        Selection.activeGameObject = car;
        EditorGUIUtility.PingObject(car);
        Debug.Log($"<color=green>✔ Successfully configured Kinematic Rigidbody and BoxCollider on '{car.name}'!</color>", car);
    }

    private static void ConfigureGameObjectAsRoad(GameObject go)
    {
        Undo.RecordObject(go.transform, "Configure Road Transform");

        // Set dimensions: Width 1.0 (10 meters = perfect for -2.5, 0, +2.5 lanes), Length 8.0 (80 meters)
        go.transform.position = new Vector3(0f, 0f, 30f);
        go.transform.localScale = new Vector3(1f, 1f, 8f);
        go.transform.rotation = Quaternion.identity;

        // Ensure texture wrap mode is Repeat for seamless UV scrolling
        EnsureTextureSettings(TexturePath);

        // Get or create RoadMaterial
        Material roadMat = GetOrCreateRoadMaterial();

        // Assign to Renderer
        Renderer rend = go.GetComponent<Renderer>();
        if (rend != null && roadMat != null)
        {
            Undo.RecordObject(rend, "Assign Road Material");
            rend.sharedMaterial = roadMat;
        }

        // Attach RoadScroller component
        RoadScroller scroller = go.GetComponent<RoadScroller>();
        if (scroller == null)
        {
            scroller = Undo.AddComponent<RoadScroller>(go);
        }

        Debug.Log($"<color=green>✔ Successfully configured '{go.name}' as a 3-Lane Scrolling Road!</color>", go);
        EditorGUIUtility.PingObject(go);
    }

    private static void EnsureTextureSettings(string path)
    {
        TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
        if (importer != null)
        {
            bool needReimport = false;
            if (importer.wrapMode != TextureWrapMode.Repeat)
            {
                importer.wrapMode = TextureWrapMode.Repeat;
                needReimport = true;
            }
            if (importer.textureType != TextureImporterType.Default)
            {
                importer.textureType = TextureImporterType.Default;
                needReimport = true;
            }
            if (needReimport)
            {
                importer.SaveAndReimport();
            }
        }
    }

    private static Material GetOrCreateRoadMaterial()
    {
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(MaterialPath);
        Texture2D tex = AssetDatabase.LoadAssetAtPath<Texture2D>(TexturePath);

        if (mat == null)
        {
            // Find URP Lit shader first, fallback to Unlit or Standard
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Universal Render Pipeline/Unlit");
            if (shader == null) shader = Shader.Find("Standard");

            mat = new Material(shader) { name = "RoadMaterial" };

            if (tex != null)
            {
                if (mat.HasProperty("_BaseMap"))
                {
                    mat.SetTexture("_BaseMap", tex);
                    mat.SetTextureScale("_BaseMap", new Vector2(1f, 8f));
                }
                mat.mainTexture = tex;
                mat.mainTextureScale = new Vector2(1f, 8f);
            }

            // Make material non-shiny asphalt
            if (mat.HasProperty("_Smoothness"))
            {
                mat.SetFloat("_Smoothness", 0.15f);
            }

            AssetDatabase.CreateAsset(mat, MaterialPath);
            AssetDatabase.SaveAssets();
            Debug.Log($"<color=cyan>Created new RoadMaterial at {MaterialPath}</color>");
        }
        else if (tex != null)
        {
            if (mat.HasProperty("_BaseMap") && mat.GetTexture("_BaseMap") == null)
            {
                mat.SetTexture("_BaseMap", tex);
                mat.SetTextureScale("_BaseMap", new Vector2(1f, 8f));
                EditorUtility.SetDirty(mat);
            }
            else if (mat.mainTexture == null)
            {
                mat.mainTexture = tex;
                mat.mainTextureScale = new Vector2(1f, 8f);
                EditorUtility.SetDirty(mat);
            }
        }

        return mat;
    }
}
#endif
