using UnityEngine;

/// <summary>
/// Collectible fuel can that restores fuel when the car drives through it.
/// </summary>
public class FuelPickup : MonoBehaviour
{
    [Tooltip("Amount of fuel to restore upon pickup.")]
    [SerializeField] private float fuelBonus = 30f;

    [Tooltip("Rotation speed for collectible visual spinning.")]
    [SerializeField] private float rotationSpeed = 90f;

    private void Update()
    {
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime, Space.World);
    }

    private void OnTriggerEnter(Collider other)
    {
        FuelSystem fuel = other.GetComponentInParent<FuelSystem>();
        if (fuel != null && fuel.HasFuel)
        {
            fuel.Refill(fuelBonus);
            Destroy(gameObject);
        }
    }
}
