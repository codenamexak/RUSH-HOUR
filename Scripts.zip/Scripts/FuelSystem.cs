using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Manages vehicle fuel consumption, dodging fuel penalty, refueling,
/// and informs GameManager when fuel runs out.
/// </summary>
public class FuelSystem : MonoBehaviour
{
    [Header("Fuel Settings")]
    [Tooltip("Maximum fuel capacity.")]
    public float maxFuel = 100f;

    [Tooltip("Current fuel level.")]
    public float currentFuel = 100f;

    [Tooltip("Fuel consumed per second of normal driving.")]
    public float idleFuelBurnRate = 1.5f;

    [Tooltip("Extra fuel consumed when shifting lanes / dodging.")]
    public float dodgeFuelCost = 5f;

    [Header("References")]
    [Tooltip("Reference to the GameManager to report out-of-fuel game over.")]
    public GameManager gameManager;

    [Header("UI (Optional)")]
    [Tooltip("Optional UI Slider representing the fuel bar.")]
    public Slider fuelSlider;

    [Tooltip("Optional UI Text displaying fuel percentage.")]
    public Text fuelText;

    private bool isOutOfFuel = false;

    private void Start()
    {
        currentFuel = maxFuel;
        UpdateUI();

        if (gameManager == null)
        {
            gameManager = Object.FindFirstObjectByType<GameManager>();
        }
    }

    private void Update()
    {
        if (isOutOfFuel) return;

        // Passive fuel burn while driving
        Consume(idleFuelBurnRate * Time.deltaTime);
    }

    /// <summary>
    /// Consumes a given amount of fuel.
    /// </summary>
    public void Consume(float amount)
    {
        if (isOutOfFuel) return;

        currentFuel = Mathf.Max(0f, currentFuel - amount);
        UpdateUI();

        if (currentFuel <= 0f)
        {
            isOutOfFuel = true;
            if (gameManager != null)
            {
                gameManager.TriggerFailure("Out of Fuel!");
            }
        }
    }

    /// <summary>
    /// Consumes extra fuel when dodging/swerving.
    /// </summary>
    public void ConsumeExtra(float amount)
    {
        Consume(amount);
    }

    /// <summary>
    /// Refills fuel by a specified amount.
    /// </summary>
    public void Refill(float amount)
    {
        if (isOutOfFuel) return;

        currentFuel = Mathf.Min(maxFuel, currentFuel + amount);
        UpdateUI();
    }

    /// <summary>
    /// Resets fuel to maximum capacity and clears out-of-fuel state.
    /// </summary>
    public void ResetFuel()
    {
        isOutOfFuel = false;
        currentFuel = maxFuel;
        UpdateUI();
    }

    private void UpdateUI()
    {
        if (fuelSlider != null)
        {
            fuelSlider.maxValue = maxFuel;
            fuelSlider.value = currentFuel;
        }

        if (fuelText != null)
        {
            fuelText.text = $"Fuel: {Mathf.CeilToInt(currentFuel)}%";
        }
    }

    public bool HasFuel => !isOutOfFuel && currentFuel > 0f;
}
