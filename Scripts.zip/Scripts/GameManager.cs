using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Controls level objective, distance progress, win/loss triggers, and level restart.
/// Attach to an empty GameObject named "GameManager".
/// </summary>
public class GameManager : MonoBehaviour
{
    [Header("Delivery Goal")]
    [Tooltip("Reference to the player's car Transform.")]
    public Transform car;

    [Tooltip("Target distance (in meters) the car must travel to complete delivery.")]
    public float deliveryDistance = 500f;

    [Header("UI References (Optional)")]
    [Tooltip("Status text displaying game progress, win, or failure message.")]
    public Text statusText;

    [Tooltip("Distance text displaying current progress (e.g. 120 / 500 m).")]
    public Text distanceText;

    [Header("Game Over / Auto Restart")]
    [Tooltip("If true, automatically restarts the level after failure.")]
    public bool autoRestartOnFailure = true;

    [Tooltip("Delay in seconds (realtime) before auto-restarting.")]
    public float restartDelay = 1.0f;

    private Vector3 startPosition;
    private bool gameOver = false;

    private void Start()
    {
        if (car != null)
        {
            startPosition = car.position;
        }

        if (statusText != null)
        {
            statusText.text = "";
        }
    }

    private void Update()
    {
        if (gameOver || car == null) return;

        float distanceTravelled = Vector3.Distance(
            new Vector3(startPosition.x, 0, startPosition.z),
            new Vector3(car.position.x, 0, car.position.z)
        );

        if (distanceText != null)
        {
            distanceText.text = $"{Mathf.FloorToInt(distanceTravelled)} / {deliveryDistance} m";
        }

        if (distanceTravelled >= deliveryDistance)
        {
            TriggerSuccess();
        }
    }

    /// <summary>
    /// Triggered when car reaches target distance.
    /// </summary>
    public void TriggerSuccess()
    {
        if (gameOver) return;
        gameOver = true;

        if (statusText != null)
        {
            statusText.text = "Package Delivered! 🎉";
        }

        Time.timeScale = 0f;
    }

    /// <summary>
    /// Triggered on car crash or running out of fuel.
    /// </summary>
    public void TriggerFailure(string reason)
    {
        if (gameOver) return;
        gameOver = true;

        if (statusText != null)
        {
            statusText.text = "Delivery Failed: " + reason;
        }

        if (autoRestartOnFailure)
        {
            StartCoroutine(AutoRestartCoroutine());
        }
        else
        {
            Time.timeScale = 0f;
        }
    }

    private System.Collections.IEnumerator AutoRestartCoroutine()
    {
        yield return new WaitForSecondsRealtime(restartDelay);
        RestartLevel();
    }

    /// <summary>
    /// Reloads current scene. Can be hooked to a UI Restart Button.
    /// </summary>
    public void RestartLevel()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().name
        );
    }
}
