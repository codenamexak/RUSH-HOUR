using UnityEngine;

/// <summary>
/// Attached to hazard objects (traffic barriers, cones, rocks, stopped cars).
/// Moves along -Z towards the stationary player (scrolling road mode) and triggers a crash on collision.
/// </summary>
[RequireComponent(typeof(Collider))]
public class Obstacle : MonoBehaviour
{
    [Header("Movement (For Scrolling Road Mode)")]
    [Tooltip("If true, moves backwards towards the player along the Z axis.")]
    [SerializeField] private bool moveTowardsPlayer = true;

    [Tooltip("Movement speed towards player along -Z (e.g. 10 - 20 m/s).")]
    [SerializeField] private float moveSpeed = 15f;

    [Tooltip("Z coordinate behind the camera at which this obstacle is destroyed.")]
    [SerializeField] private float despawnZ = -15f;

    [Header("Impact Settings")]
    [Tooltip("Destroy this obstacle immediately upon colliding with the car.")]
    [SerializeField] private bool destroyOnImpact = false;

    private bool hasCrashed = false;

    private void Awake()
    {
        // Ensure this obstacle has a kinematic Rigidbody so Unity triggers collision/trigger events reliably
        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = gameObject.AddComponent<Rigidbody>();
        }
        rb.isKinematic = true;
        rb.useGravity = false;
    }

    private void Update()
    {
        if (moveTowardsPlayer)
        {
            // Move backwards towards the player
            transform.Translate(Vector3.back * moveSpeed * Time.deltaTime, Space.World);

            // Clean up when behind the camera
            if (transform.position.z <= despawnZ)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        CheckCrash(other.gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        CheckCrash(collision.gameObject);
    }

    private void CheckCrash(GameObject target)
    {
        if (hasCrashed || target == null) return;

        // Check for CarLaneMovement in parent or children
        CarLaneMovement laneMovement = target.GetComponentInParent<CarLaneMovement>() 
                                     ?? target.GetComponentInChildren<CarLaneMovement>();
        if (laneMovement != null && laneMovement.IsAlive())
        {
            if (!IsSpatialHit(laneMovement.transform)) return;

            hasCrashed = true;
            laneMovement.OnCrash();
            HandleImpactCleanup();
            return;
        }

        // Check for CarController in parent or children
        CarController car = target.GetComponentInParent<CarController>() 
                          ?? target.GetComponentInChildren<CarController>();
        if (car != null && car.IsAlive())
        {
            if (!IsSpatialHit(car.transform)) return;

            hasCrashed = true;
            car.OnCrash();
            HandleImpactCleanup();
            return;
        }
    }

    /// <summary>
    /// Validates that the obstacle is genuinely within collision range of the car in both X and Z.
    /// Prevents phantom triggers, out-of-lane collisions, and premature crashes.
    /// </summary>
    private bool IsSpatialHit(Transform carTransform)
    {
        if (carTransform == null) return false;

        // 1. Check longitudinal Z distance (must be close to the car bumper, not 50m ahead!)
        float deltaZ = transform.position.z - carTransform.position.z;
        if (deltaZ > 2.5f || deltaZ < -3.5f)
        {
            return false;
        }

        // 2. Check lateral X distance (must be in the same lane!)
        // In a 2.5m lane setup, two adjacent lanes are 2.5m apart.
        // A car and hazard block only touch if deltaX <= 1.6m.
        float deltaX = Mathf.Abs(transform.position.x - carTransform.position.x);
        if (deltaX > 1.6f)
        {
            return false;
        }

        return true;
    }

    private void HandleImpactCleanup()
    {
        if (destroyOnImpact)
        {
            Destroy(gameObject);
        }
    }

    public void SetSpeed(float newSpeed)
    {
        moveSpeed = newSpeed;
    }
}
