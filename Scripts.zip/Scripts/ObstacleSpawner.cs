using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Spawns obstacles in the 3 lanes ahead of the player at periodic intervals.
/// Ensures at least one lane is always open so every wave is dodgeable.
/// </summary>
public class ObstacleSpawner : MonoBehaviour
{
    [Header("Spawn Timing")]
    [Tooltip("Time (in seconds) between each obstacle wave.")]
    [Range(0.8f, 5f)]
    [SerializeField] private float spawnInterval = 2.0f;

    [Tooltip("Initial delay before spawning the first obstacle.")]
    [SerializeField] private float startDelay = 2.0f;

    [Tooltip("Speed given to spawned obstacles (should match road scroll feel).")]
    [SerializeField] private float obstacleSpeed = 15f;

    [Header("Spawn Position")]
    [Tooltip("Z position ahead of the player where obstacles appear.")]
    [SerializeField] private float spawnZ = 50f;

    [Tooltip("Y height for spawned obstacles above the road.")]
    [SerializeField] private float spawnY = 0.5f;

    [Tooltip("Horizontal X positions for the 3 lanes (Left, Center, Right).")]
    [SerializeField] private float[] laneXPositions = new float[] { -2.5f, 0f, 2.5f };

    [Header("Prefabs (Optional)")]
    [Tooltip("Custom obstacle prefabs. If empty, procedural hazard blocks will be created automatically.")]
    [SerializeField] private GameObject[] obstaclePrefabs;

    [Tooltip("Optional Fuel Pickup prefab to spawn periodically in empty lanes.")]
    [SerializeField] private GameObject fuelPickupPrefab;

    [Tooltip("Chance (0 to 1) to spawn a fuel pickup instead of an obstacle in one wave.")]
    [Range(0f, 0.5f)]
    [SerializeField] private float fuelSpawnChance = 0.2f;

    [Header("References")]
    [SerializeField] private CarLaneMovement carMovement;
    [SerializeField] private CarController carController;

    private float timer = 0f;
    private Material defaultHazardMaterial;

    private void Start()
    {
        timer = spawnInterval - startDelay;

        // Auto-find car reference
        if (carMovement == null) carMovement = Object.FindFirstObjectByType<CarLaneMovement>();
        if (carController == null) carController = Object.FindFirstObjectByType<CarController>();
    }

    private void Update()
    {
        // Don't spawn if car has crashed
        if (carMovement != null && !carMovement.IsAlive()) return;
        if (carController != null && !carController.IsAlive()) return;

        timer += Time.deltaTime;
        if (timer >= spawnInterval)
        {
            timer = 0f;
            SpawnWave();
        }
    }

    /// <summary>
    /// Spawns 1 or 2 obstacles across the 3 lanes, guaranteeing at least 1 lane remains clear.
    /// </summary>
    public void SpawnWave()
    {
        // Decide if this wave is a fuel pickup bonus
        bool spawnFuel = (fuelPickupPrefab != null && Random.value < fuelSpawnChance);

        // Pick 1 or 2 lanes to fill (never all 3!)
        List<int> availableLanes = new List<int> { 0, 1, 2 };
        int lanesToFill = (Random.value < 0.35f) ? 2 : 1; // 35% chance of 2 obstacles, 65% chance of 1

        for (int i = 0; i < lanesToFill; i++)
        {
            int chosenIndex = Random.Range(0, availableLanes.Count);
            int lane = availableLanes[chosenIndex];
            availableLanes.RemoveAt(chosenIndex);

            float x = laneXPositions[lane];
            Vector3 spawnPos = new Vector3(x, spawnY, spawnZ);

            if (spawnFuel && i == 0)
            {
                SpawnObject(fuelPickupPrefab, spawnPos);
            }
            else
            {
                SpawnObstacle(spawnPos);
            }
        }
    }

    private void SpawnObstacle(Vector3 position)
    {
        GameObject obstacleObj;

        if (obstaclePrefabs != null && obstaclePrefabs.Length > 0)
        {
            GameObject prefab = obstaclePrefabs[Random.Range(0, obstaclePrefabs.Length)];
            obstacleObj = Instantiate(prefab, position, Quaternion.identity);
        }
        else
        {
            // Procedural default hazard block
            obstacleObj = CreateProceduralHazardBlock(position);
        }

        // Configure speed
        Obstacle obsComp = obstacleObj.GetComponent<Obstacle>();
        if (obsComp != null)
        {
            obsComp.SetSpeed(obstacleSpeed);
        }
    }

    private void SpawnObject(GameObject prefab, Vector3 position)
    {
        if (prefab == null) return;
        GameObject obj = Instantiate(prefab, position, Quaternion.identity);

        // Ensure it moves towards player if it has Obstacle or a mover
        Obstacle obs = obj.GetComponent<Obstacle>();
        if (obs != null)
        {
            obs.SetSpeed(obstacleSpeed);
        }
    }

    /// <summary>
    /// Creates a clean, ready-to-use hazard block if no custom prefabs are assigned.
    /// </summary>
    private GameObject CreateProceduralHazardBlock(Vector3 position)
    {
        GameObject block = GameObject.CreatePrimitive(PrimitiveType.Cube);
        block.name = "Hazard_Barrier";
        block.transform.position = position;
        block.transform.localScale = new Vector3(1.6f, 0.8f, 0.8f);

        // Setup BoxCollider as trigger
        BoxCollider col = block.GetComponent<BoxCollider>();
        if (col != null)
        {
            col.isTrigger = true;
        }

        // Add kinematic Rigidbody so Unity triggers collision events reliably
        Rigidbody rb = block.GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = block.AddComponent<Rigidbody>();
        }
        rb.isKinematic = true;
        rb.useGravity = false;

        // Tag as Obstacle
        block.tag = "Obstacle";

        // Add Obstacle component
        Obstacle obs = block.AddComponent<Obstacle>();
        obs.SetSpeed(obstacleSpeed);

        // Color hazard orange/red
        Renderer rend = block.GetComponent<Renderer>();
        if (rend != null)
        {
            if (defaultHazardMaterial == null)
            {
                Shader s = Shader.Find("Universal Render Pipeline/Lit");
                if (s == null) s = Shader.Find("Standard");
                defaultHazardMaterial = new Material(s)
                {
                    color = new Color(0.95f, 0.35f, 0.1f) // Bright safety orange
                };
            }
            rend.material = defaultHazardMaterial;
        }

        return block;
    }

    /// <summary>
    /// Destroys all currently active obstacles in the scene.
    /// </summary>
    public void ClearAllObstacles()
    {
        Obstacle[] obstacles = Object.FindObjectsByType<Obstacle>(FindObjectsSortMode.None);
        foreach (Obstacle obs in obstacles)
        {
            if (obs != null)
            {
                Destroy(obs.gameObject);
            }
        }
    }

    /// <summary>
    /// Resets the spawn timer.
    /// </summary>
    public void ResetSpawner()
    {
        timer = spawnInterval - startDelay;
    }
}
